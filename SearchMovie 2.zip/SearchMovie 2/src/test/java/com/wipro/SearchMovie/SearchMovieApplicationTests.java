package com.wipro.SearchMovie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SearchMovieApplicationTests {

	@Test
	void contextLoads() {
	}

}
