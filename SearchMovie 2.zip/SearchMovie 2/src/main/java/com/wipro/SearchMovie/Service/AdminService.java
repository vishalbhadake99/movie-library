package com.wipro.SearchMovie.Service;

import com.wipro.SearchMovie.entity.Admin;

public interface AdminService {

    String loginUser(Admin admin, String type);
}
