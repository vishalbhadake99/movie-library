package com.wipro.SearchMovie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SearchMovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(SearchMovieApplication.class, args);
	}

}
